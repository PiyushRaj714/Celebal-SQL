# SQL Solutions for Celebal Internship

Welcome to my GitHub repository where I post SQL solutions developed during my internship at Celebal Technologies. This collection includes various SQL queries, scripts, and projects showcasing my learning and problem-solving skills in SQL.


## Contact

If you have any questions or suggestions, feel free to reach out to me at:
- **Name**: [Rakshit Gupta](https://github.com/Rakshitgupta9/Celebal-Internship)
- **ID**: CT_CSI_SQ_4156
- **Email**: guptarakshit9858@gmail.com
- **LinkedIn**: [Rakshit Gupta](https://www.linkedin.com/in/rakshit9/)
