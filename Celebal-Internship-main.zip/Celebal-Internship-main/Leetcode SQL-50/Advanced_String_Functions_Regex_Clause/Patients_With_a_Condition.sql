SELECT * FROM patients WHERE conditions REGEXP '\\bDIAB1'



--Rakshit Gupta
